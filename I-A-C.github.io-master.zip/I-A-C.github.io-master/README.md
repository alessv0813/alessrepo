# ExodusRedux Repository addon
## Current Version: 0.0.8

Instructions for adding this repo:


<p align="left">
  <ul>
    <li>Go to the Kodi file manager.</li>
    <li>Click on "Add source"</li>
    <li>The path for the source is <code>https://i-a-c.github.io/</code> (Give it the name "ExodusRedux Repo").</li>
    <li>Go to "Addons"</li>
    <li>In Addons, install an addon from zip.  When it asks for the location, select "ExodusRedux Repo", and install <a href="repository.exodusredux-0.0.8.zip">repository.exodusredux-0.0.8.zip</a>.</li>
    <li>Go back to Addons install, but this time, select "Install from repository"</li>
    <li>Select the "ExodusRedux Repository"</li>
    <li>Go into the "Video add-ons" section in the repo, and you'll find Exodus Redux</li>
  </ul>
</p>

## Enjoy!
